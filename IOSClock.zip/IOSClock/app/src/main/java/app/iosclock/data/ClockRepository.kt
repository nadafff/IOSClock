package app.iosclock.data

import android.content.Context
import android.content.SharedPreferences
import android.media.RingtoneManager
import org.json.JSONArray
import org.json.JSONObject

/** Single persistence entry point (SharedPreferences + JSON); also used by receivers/services. */
class ClockRepository private constructor(context: Context) {

    val prefs: SharedPreferences =
        context.applicationContext.getSharedPreferences("ios_clock", Context.MODE_PRIVATE)

    // ---------------------------------------------------------------- alarms
    fun loadAlarms(): List<AlarmItem> = runCatching {
        val arr = JSONArray(prefs.getString(KEY_ALARMS, "[]"))
        (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            val d = o.getJSONArray("days")
            AlarmItem(
                id = o.getInt("id"),
                hour = o.getInt("hour"),
                minute = o.getInt("minute"),
                days = (0 until d.length()).map { d.getInt(it) }.toSet(),
                label = o.optString("label", ""),
                soundUri = o.optString("sound", defaultSound()),
                snooze = o.optBoolean("snooze", true),
                enabled = o.optBoolean("enabled", true)
            )
        }
    }.getOrDefault(emptyList())

    fun saveAlarms(list: List<AlarmItem>) {
        val arr = JSONArray()
        list.forEach { a ->
            arr.put(
                JSONObject()
                    .put("id", a.id)
                    .put("hour", a.hour)
                    .put("minute", a.minute)
                    .put("days", JSONArray(a.days.toList()))
                    .put("label", a.label)
                    .put("sound", a.soundUri)
                    .put("snooze", a.snooze)
                    .put("enabled", a.enabled)
            )
        }
        prefs.edit().putString(KEY_ALARMS, arr.toString()).apply()
    }

    // ---------------------------------------------------------------- cities
    fun loadCities(): List<String> {
        val raw = prefs.getString(KEY_CITIES, null)
        if (raw == null) {
            val defaults = listOf(
                CityCatalog.forSystemZone(),
                CityCatalog.all.first { it.name == "London" },
                CityCatalog.all.first { it.name == "New York" },
                CityCatalog.all.first { it.name == "Tokyo" }
            ).map { it.key }.distinct()
            saveCities(defaults)
            return defaults
        }
        return runCatching {
            val arr = JSONArray(raw)
            (0 until arr.length()).map { arr.getString(it) }
        }.getOrDefault(emptyList())
    }

    fun saveCities(keys: List<String>) {
        prefs.edit().putString(KEY_CITIES, JSONArray(keys).toString()).apply()
    }

    // ------------------------------------------------------------- stopwatch
    fun loadStopwatch(): StopwatchState = runCatching {
        val o = JSONObject(prefs.getString(KEY_STOPWATCH, "{}"))
        val laps = o.optJSONArray("laps") ?: JSONArray()
        var running = o.optBoolean("running", false)
        val startedAt = o.optLong("startedAt", 0L)
        var acc = o.optLong("acc", 0L)
        // elapsedRealtime restarts at boot; a "running" stopwatch from before a reboot is frozen.
        if (running && startedAt > android.os.SystemClock.elapsedRealtime()) {
            running = false
        }
        StopwatchState(
            running = running,
            startedAt = startedAt,
            accumulatedMs = acc,
            laps = (0 until laps.length()).map {
                val l = laps.getJSONObject(it)
                LapItem(l.getInt("n"), l.getLong("lap"), l.getLong("total"))
            }
        )
    }.getOrDefault(StopwatchState())

    fun saveStopwatch(s: StopwatchState) {
        val laps = JSONArray()
        s.laps.forEach {
            laps.put(JSONObject().put("n", it.number).put("lap", it.lapMs).put("total", it.totalMs))
        }
        prefs.edit().putString(
            KEY_STOPWATCH,
            JSONObject()
                .put("running", s.running)
                .put("startedAt", s.startedAt)
                .put("acc", s.accumulatedMs)
                .put("laps", laps)
                .toString()
        ).apply()
    }

    // ----------------------------------------------------------------- timer
    fun loadTimer(): TimerState = runCatching {
        val o = JSONObject(prefs.getString(KEY_TIMER, "{}"))
        TimerState(
            status = TimerStatus.valueOf(o.optString("status", "IDLE")),
            totalMs = o.optLong("total", 5 * 60_000L),
            endAt = o.optLong("endAt", 0L),
            remainingMs = o.optLong("remaining", 0L),
            soundUri = o.optString("sound", "").ifEmpty { defaultSound() }
        )
    }.getOrDefault(TimerState(soundUri = defaultSound()))

    fun saveTimer(t: TimerState) {
        prefs.edit().putString(
            KEY_TIMER,
            JSONObject()
                .put("status", t.status.name)
                .put("total", t.totalMs)
                .put("endAt", t.endAt)
                .put("remaining", t.remainingMs)
                .put("sound", t.soundUri)
                .toString()
        ).apply()
    }

    companion object {
        const val KEY_ALARMS = "alarms"
        const val KEY_CITIES = "cities"
        const val KEY_STOPWATCH = "stopwatch"
        const val KEY_TIMER = "timer"

        @Volatile
        private var instance: ClockRepository? = null

        fun get(context: Context): ClockRepository =
            instance ?: synchronized(this) {
                instance ?: ClockRepository(context).also { instance = it }
            }

        fun defaultSound(): String =
            RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)?.toString() ?: ""
    }
}
