package app.iosclock.ui

import android.text.format.DateFormat
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandHorizontally
import androidx.compose.animation.shrinkHorizontally
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.zIndex
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import app.iosclock.ClockViewModel
import app.iosclock.data.City
import app.iosclock.data.CityCatalog
import kotlinx.coroutines.delay
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.ZonedDateTime
import java.util.Locale
import kotlin.math.abs

private val ROW_HEIGHT = 84.dp

@Composable
fun WorldClockScreen(vm: ClockViewModel, onAdd: () -> Unit) {
    val c = LocalIos.current
    val ctx = LocalContext.current
    val is24 = remember { DateFormat.is24HourFormat(ctx) }
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) {
        while (true) {
            now = System.currentTimeMillis()
            delay(1000L - (now % 1000L) + 5L)
        }
    }

    var editing by remember { mutableStateOf(false) }
    var revealedKey by remember { mutableStateOf<String?>(null) }
    var draggingKey by remember { mutableStateOf<String?>(null) }
    var dragOffset by remember { mutableFloatStateOf(0f) }
    val rowPx = with(LocalDensity.current) { ROW_HEIGHT.toPx() }

    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        NavBar(
            left = if (vm.cities.isEmpty()) null else if (editing) "Done" else "Edit",
            onLeft = { editing = !editing; revealedKey = null },
            onPlus = onAdd
        )
        LargeTitle("World Clock")
        Hairline()
        LazyColumn(Modifier.fillMaxSize()) {
            itemsIndexed(vm.cities, key = { _, k -> k }) { _, key ->
                val city = CityCatalog.parse(key)
                val zone = CityCatalog.zoneOf(city)
                val t = Instant.ofEpochMilli(now).atZone(zone)
                val isDragged = draggingKey == key

                SwipeRow(
                    revealed = revealedKey == key,
                    onRevealChange = { revealedKey = if (it) key else null },
                    onDelete = { vm.removeCity(key); revealedKey = null },
                    modifier = Modifier
                        .zIndex(if (isDragged) 1f else 0f)
                        .graphicsLayer { translationY = if (isDragged) dragOffset else 0f }
                ) {
                    Column(Modifier.background(c.bg)) {
                        Row(
                            Modifier.fillMaxWidth().height(ROW_HEIGHT).padding(horizontal = 20.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            AnimatedVisibility(
                                visible = editing,
                                enter = expandHorizontally(),
                                exit = shrinkHorizontally()
                            ) {
                                Row {
                                    MinusButton { revealedKey = if (revealedKey == key) null else key }
                                    Spacer(Modifier.width(14.dp))
                                }
                            }
                            Column(Modifier.weight(1f)) {
                                IText(dayAndOffset(t, zone), 13.sp, c.secondary, maxLines = 1)
                                IText(city.name, 28.sp, c.label, maxLines = 1)
                            }
                            if (editing) {
                                Box(
                                    Modifier
                                        .size(40.dp)
                                        .pointerInput(key) {
                                            detectDragGestures(
                                                onDragStart = { draggingKey = key; dragOffset = 0f },
                                                onDragEnd = { draggingKey = null; dragOffset = 0f },
                                                onDragCancel = { draggingKey = null; dragOffset = 0f },
                                                onDrag = { change, amount ->
                                                    change.consume()
                                                    dragOffset += amount.y
                                                    val i = vm.cities.indexOf(key)
                                                    if (dragOffset > rowPx / 2 && i < vm.cities.lastIndex) {
                                                        vm.moveCity(i, i + 1); dragOffset -= rowPx
                                                    } else if (dragOffset < -rowPx / 2 && i > 0) {
                                                        vm.moveCity(i, i - 1); dragOffset += rowPx
                                                    }
                                                }
                                            )
                                        },
                                    contentAlignment = Alignment.Center
                                ) {
                                    Canvas(Modifier.size(22.dp, 16.dp)) {
                                        val w = 2.dp.toPx()
                                        listOf(0f, 0.5f, 1f).forEach { f ->
                                            val y = w / 2 + (size.height - w) * f
                                            drawLine(c.secondary, Offset(0f, y), Offset(size.width, y), w, StrokeCap.Round)
                                        }
                                    }
                                }
                            } else {
                                val (main, suffix) = timeParts(t, is24)
                                Row {
                                    IText(main, 50.sp, c.label, FontWeight.Light, tnum = true, modifier = Modifier.alignByBaseline())
                                    if (suffix.isNotEmpty()) {
                                        IText(" $suffix", 22.sp, c.label, FontWeight.Light, modifier = Modifier.alignByBaseline())
                                    }
                                }
                            }
                        }
                        Hairline(startPadding = 20.dp)
                    }
                }
            }
        }
    }
}

/** "10:41" + "AM", or "22:41" + "" in 24-hour mode. */
fun timeParts(t: ZonedDateTime, is24: Boolean): Pair<String, String> =
    if (is24) Pair(String.format(Locale.US, "%02d:%02d", t.hour, t.minute), "")
    else {
        val h = if (t.hour % 12 == 0) 12 else t.hour % 12
        Pair(String.format(Locale.US, "%d:%02d", h, t.minute), if (t.hour < 12) "AM" else "PM")
    }

private fun dayAndOffset(t: ZonedDateTime, zone: ZoneId): String {
    val local = ZonedDateTime.now(ZoneId.systemDefault())
    val today = local.toLocalDate()
    val day = when (t.toLocalDate()) {
        today -> "Today"
        today.plusDays(1) -> "Tomorrow"
        today.minusDays(1) -> "Yesterday"
        else -> t.toLocalDate().toString()
    }
    val diffMin = (t.offset.totalSeconds - local.offset.totalSeconds) / 60
    val sign = if (diffMin < 0) "-" else "+"
    val a = abs(diffMin)
    val h = a / 60
    val m = a % 60
    val hrs = if (m == 0) "$h${if (h == 1) "HR" else "HRS"}" else "$h:${String.format(Locale.US, "%02d", m)}HRS"
    return "$day, $sign$hrs"
}

// ------------------------------------------------------------ city picker
@Composable
fun CityPicker(onPick: (City) -> Unit, onCancel: () -> Unit) {
    val c = LocalIos.current
    androidx.activity.compose.BackHandler { onCancel() }
    var query by remember { mutableStateOf("") }
    val filtered = remember(query) {
        val q = query.trim()
        if (q.isEmpty()) CityCatalog.all
        else CityCatalog.all.filter {
            it.name.contains(q, ignoreCase = true) || it.country.contains(q, ignoreCase = true)
        }
    }
    val grouped = remember(filtered) { filtered.groupBy { it.name.first().uppercaseChar() }.toSortedMap() }

    Column(Modifier.fillMaxSize().statusBarsPadding().imePadding()) {
        Spacer(Modifier.height(14.dp))
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 20.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IText("Choose a City", 17.sp, c.label, FontWeight.SemiBold)
            IText("Cancel", 17.sp, c.accent, modifier = Modifier.tap(onClick = onCancel))
        }
        Spacer(Modifier.height(12.dp))
        Box(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp)
                .clip(RoundedCornerShape(10.dp))
                .background(c.card)
                .padding(horizontal = 12.dp, vertical = 10.dp)
        ) {
            if (query.isEmpty()) IText("Search", 17.sp, c.secondary)
            BasicTextField(
                value = query,
                onValueChange = { query = it },
                singleLine = true,
                textStyle = TextStyle(color = c.label, fontSize = 17.sp),
                cursorBrush = SolidColor(c.accent),
                modifier = Modifier.fillMaxWidth()
            )
        }
        Spacer(Modifier.height(8.dp))
        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 24.dp)) {
            grouped.forEach { (letter, list) ->
                item(key = "h$letter") {
                    IText(
                        letter.toString(), 15.sp, c.secondary, FontWeight.SemiBold,
                        modifier = Modifier.fillMaxWidth().background(c.card).padding(horizontal = 20.dp, vertical = 4.dp)
                    )
                }
                items(list, key = { it.key }) { city ->
                    Column(Modifier.fillMaxWidth().tap { onPick(city) }) {
                        Row(
                            Modifier.fillMaxWidth().height(48.dp).padding(horizontal = 20.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            IText(city.name, 17.sp, c.label)
                            Spacer(Modifier.width(8.dp))
                            IText(city.country, 15.sp, c.secondary, maxLines = 1)
                        }
                        Hairline(startPadding = 20.dp)
                    }
                }
            }
        }
    }
}
