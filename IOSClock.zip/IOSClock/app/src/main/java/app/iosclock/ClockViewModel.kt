package app.iosclock

import android.app.Application
import android.content.SharedPreferences
import android.os.SystemClock
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import app.iosclock.alarm.AlarmScheduler
import app.iosclock.data.AlarmItem
import app.iosclock.data.City
import app.iosclock.data.ClockRepository
import app.iosclock.data.LapItem
import app.iosclock.data.StopwatchState
import app.iosclock.data.TimerState
import app.iosclock.data.TimerStatus

class ClockViewModel(app: Application) : AndroidViewModel(app) {
    private val ctx = app.applicationContext
    private val repo = ClockRepository.get(ctx)

    var alarms by mutableStateOf(repo.loadAlarms())
        private set
    var cities by mutableStateOf(repo.loadCities())
        private set
    var stopwatch by mutableStateOf(repo.loadStopwatch())
        private set
    var timer by mutableStateOf(repo.loadTimer())
        private set

    // Receivers/services write to the same prefs (one-shot alarm switching off, timer finishing).
    // Keep a strong reference: SharedPreferences holds listeners weakly.
    private val listener = SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
        when (key) {
            ClockRepository.KEY_ALARMS -> alarms = repo.loadAlarms()
            ClockRepository.KEY_TIMER -> timer = repo.loadTimer()
        }
    }

    init {
        repo.prefs.registerOnSharedPreferenceChangeListener(listener)
        AlarmScheduler.rescheduleAll(ctx)
    }

    override fun onCleared() {
        repo.prefs.unregisterOnSharedPreferenceChangeListener(listener)
    }

    // --------------------------------------------------------------- cities
    fun addCity(city: City) {
        if (city.key in cities) return
        cities = cities + city.key
        repo.saveCities(cities)
    }

    fun removeCity(key: String) {
        cities = cities - key
        repo.saveCities(cities)
    }

    fun moveCity(from: Int, to: Int) {
        if (from !in cities.indices || to !in cities.indices) return
        val m = cities.toMutableList()
        m.add(to, m.removeAt(from))
        cities = m
        repo.saveCities(cities)
    }

    // --------------------------------------------------------------- alarms
    fun newAlarmId(): Int = (alarms.maxOfOrNull { it.id } ?: 0) + 1

    fun saveAlarm(a: AlarmItem) {
        commitAlarms(alarms.filter { it.id != a.id } + a)
        if (a.enabled) AlarmScheduler.schedule(ctx, a) else AlarmScheduler.cancel(ctx, a.id)
    }

    fun deleteAlarm(id: Int) {
        AlarmScheduler.cancel(ctx, id)
        commitAlarms(alarms.filter { it.id != id })
    }

    fun toggleAlarm(id: Int, on: Boolean) {
        val a = alarms.firstOrNull { it.id == id } ?: return
        saveAlarm(a.copy(enabled = on))
    }

    private fun commitAlarms(list: List<AlarmItem>) {
        alarms = list.sortedWith(compareBy({ it.hour }, { it.minute }))
        repo.saveAlarms(alarms)
    }

    // ------------------------------------------------------------ stopwatch
    private fun commitStopwatch(s: StopwatchState) {
        stopwatch = s
        repo.saveStopwatch(s)
    }

    fun stopwatchStart() {
        if (stopwatch.running) return
        commitStopwatch(stopwatch.copy(running = true, startedAt = SystemClock.elapsedRealtime()))
    }

    fun stopwatchStop() {
        if (!stopwatch.running) return
        val acc = stopwatch.elapsed(SystemClock.elapsedRealtime())
        commitStopwatch(stopwatch.copy(running = false, accumulatedMs = acc))
    }

    fun stopwatchLap() {
        if (!stopwatch.running) return
        val total = stopwatch.elapsed(SystemClock.elapsedRealtime())
        val prevTotal = stopwatch.laps.firstOrNull()?.totalMs ?: 0L
        val lap = LapItem(stopwatch.laps.size + 1, total - prevTotal, total)
        commitStopwatch(stopwatch.copy(laps = listOf(lap) + stopwatch.laps))
    }

    fun stopwatchReset() {
        commitStopwatch(StopwatchState())
    }

    // ---------------------------------------------------------------- timer
    private fun commitTimer(t: TimerState) {
        timer = t
        repo.saveTimer(t)
    }

    fun timerStart(totalMs: Long) {
        if (totalMs <= 0L) return
        val end = System.currentTimeMillis() + totalMs
        commitTimer(timer.copy(status = TimerStatus.RUNNING, totalMs = totalMs, endAt = end, remainingMs = totalMs))
        AlarmScheduler.scheduleTimer(ctx, end)
    }

    fun timerPause() {
        if (timer.status != TimerStatus.RUNNING) return
        val remaining = (timer.endAt - System.currentTimeMillis()).coerceAtLeast(0L)
        AlarmScheduler.cancelTimer(ctx)
        commitTimer(timer.copy(status = TimerStatus.PAUSED, remainingMs = remaining, endAt = 0L))
    }

    fun timerResume() {
        if (timer.status != TimerStatus.PAUSED) return
        val end = System.currentTimeMillis() + timer.remainingMs
        commitTimer(timer.copy(status = TimerStatus.RUNNING, endAt = end))
        AlarmScheduler.scheduleTimer(ctx, end)
    }

    fun timerCancel() {
        AlarmScheduler.cancelTimer(ctx)
        commitTimer(timer.copy(status = TimerStatus.IDLE, endAt = 0L, remainingMs = 0L))
    }

    fun setTimerSound(uri: String) {
        commitTimer(timer.copy(soundUri = uri))
    }

    fun rememberTimerDuration(ms: Long) {
        if (timer.status == TimerStatus.IDLE && ms != timer.totalMs) commitTimer(timer.copy(totalMs = ms))
    }
}
