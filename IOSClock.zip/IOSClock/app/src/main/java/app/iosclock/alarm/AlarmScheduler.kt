package app.iosclock.alarm

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import app.iosclock.MainActivity
import app.iosclock.data.AlarmItem
import app.iosclock.data.ClockRepository
import app.iosclock.data.TimerStatus
import app.iosclock.ring.RingService
import java.time.ZonedDateTime

object AlarmScheduler {
    const val ACTION_FIRE = "app.iosclock.action.ALARM_FIRE"
    const val ACTION_TIMER = "app.iosclock.action.TIMER_FIRE"
    const val EXTRA_SNOOZED = "snoozed"
    const val SNOOZE_MINUTES = 9L

    /** Next time this alarm should fire, strictly after [from]. */
    fun nextTrigger(a: AlarmItem, from: ZonedDateTime = ZonedDateTime.now()): ZonedDateTime {
        val base = from.withHour(a.hour).withMinute(a.minute).withSecond(0).withNano(0)
        if (a.days.isEmpty()) {
            return if (base.isAfter(from)) base else base.plusDays(1)
        }
        for (i in 0..7) {
            val cand = base.plusDays(i.toLong())
            if (cand.dayOfWeek.value in a.days && cand.isAfter(from)) return cand
        }
        return base.plusDays(1)
    }

    private fun alarmManager(ctx: Context) = ctx.getSystemService(AlarmManager::class.java)

    private fun firePending(ctx: Context, id: Int, snoozed: Boolean): PendingIntent {
        val i = Intent(ctx, AlarmReceiver::class.java)
            .setAction(ACTION_FIRE)
            .setData(Uri.parse("iosclock://alarm/$id/${if (snoozed) "s" else "a"}"))
            .putExtra(RingService.EXTRA_ALARM_ID, id)
            .putExtra(EXTRA_SNOOZED, snoozed)
        return PendingIntent.getBroadcast(
            ctx, if (snoozed) 100_000 + id else id, i,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    private fun showAppPending(ctx: Context): PendingIntent =
        PendingIntent.getActivity(
            ctx, 0, Intent(ctx, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

    private fun setClock(ctx: Context, whenMs: Long, pi: PendingIntent) {
        val am = alarmManager(ctx)
        try {
            am.setAlarmClock(AlarmManager.AlarmClockInfo(whenMs, showAppPending(ctx)), pi)
        } catch (_: SecurityException) {
            // Exact-alarm permission revoked: fall back to the closest inexact option.
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, whenMs, pi)
        }
    }

    fun schedule(ctx: Context, a: AlarmItem) {
        setClock(ctx, nextTrigger(a).toInstant().toEpochMilli(), firePending(ctx, a.id, false))
    }

    fun cancel(ctx: Context, id: Int) {
        alarmManager(ctx).cancel(firePending(ctx, id, false))
        alarmManager(ctx).cancel(firePending(ctx, id, true))
    }

    fun scheduleSnooze(ctx: Context, id: Int) {
        val whenMs = System.currentTimeMillis() + SNOOZE_MINUTES * 60_000L
        setClock(ctx, whenMs, firePending(ctx, id, true))
    }

    fun rescheduleAll(ctx: Context) {
        val repo = ClockRepository.get(ctx)
        repo.loadAlarms().forEach { if (it.enabled) schedule(ctx, it) else cancel(ctx, it.id) }
        val t = repo.loadTimer()
        if (t.status == TimerStatus.RUNNING) {
            if (t.endAt > System.currentTimeMillis()) {
                scheduleTimer(ctx, t.endAt)
            } else {
                repo.saveTimer(t.copy(status = TimerStatus.IDLE, remainingMs = 0L, endAt = 0L))
            }
        }
    }

    // ----------------------------------------------------------------- timer
    private fun timerPending(ctx: Context): PendingIntent {
        val i = Intent(ctx, TimerReceiver::class.java)
            .setAction(ACTION_TIMER)
            .setData(Uri.parse("iosclock://timer"))
        return PendingIntent.getBroadcast(
            ctx, 7, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    fun scheduleTimer(ctx: Context, endAtMs: Long) {
        val am = alarmManager(ctx)
        val pi = timerPending(ctx)
        try {
            am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, endAtMs, pi)
        } catch (_: SecurityException) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, endAtMs, pi)
        }
    }

    fun cancelTimer(ctx: Context) {
        alarmManager(ctx).cancel(timerPending(ctx))
    }

    @Suppress("unused")
    fun canScheduleExact(ctx: Context): Boolean =
        Build.VERSION.SDK_INT < 31 || alarmManager(ctx).canScheduleExactAlarms()
}
