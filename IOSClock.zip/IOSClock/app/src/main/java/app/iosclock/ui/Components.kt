package app.iosclock.ui

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.Orientation
import androidx.compose.foundation.gestures.draggable
import androidx.compose.foundation.gestures.rememberDraggableState
import androidx.compose.foundation.gestures.snapping.rememberSnapFlingBehavior
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.matchParentSize
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicText
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.abs
import kotlin.math.roundToInt

// ------------------------------------------------------------------ text
@Composable
fun IText(
    text: String,
    size: TextUnit = 17.sp,
    color: Color = LocalIos.current.label,
    weight: FontWeight = FontWeight.Normal,
    modifier: Modifier = Modifier,
    maxLines: Int = Int.MAX_VALUE,
    align: TextAlign = TextAlign.Unspecified,
    tnum: Boolean = false
) {
    BasicText(
        text = text,
        modifier = modifier,
        style = TextStyle(
            color = color,
            fontSize = size,
            fontWeight = weight,
            textAlign = align,
            fontFeatureSettings = if (tnum) "tnum" else null
        ),
        maxLines = maxLines,
        overflow = TextOverflow.Ellipsis
    )
}

/** Tap without ripple/indication, like iOS. */
@Composable
fun Modifier.tap(enabled: Boolean = true, onClick: () -> Unit): Modifier =
    this.clickable(
        interactionSource = remember { MutableInteractionSource() },
        indication = null,
        enabled = enabled,
        onClick = onClick
    )

@Composable
fun Hairline(startPadding: Dp = 0.dp) {
    Box(
        Modifier
            .fillMaxWidth()
            .padding(start = startPadding)
            .height(0.5.dp)
            .background(LocalIos.current.separator)
    )
}

// ------------------------------------------------------------ nav / title
@Composable
fun NavBar(
    left: String?,
    onLeft: () -> Unit,
    onPlus: (() -> Unit)?
) {
    val c = LocalIos.current
    Row(
        Modifier
            .fillMaxWidth()
            .height(48.dp)
            .padding(horizontal = 20.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        if (left != null) {
            IText(left, 17.sp, c.accent, modifier = Modifier.tap(onClick = onLeft))
        } else {
            Box(Modifier.size(1.dp))
        }
        if (onPlus != null) {
            Box(Modifier.size(32.dp).tap(onClick = onPlus), contentAlignment = Alignment.Center) {
                Canvas(Modifier.size(20.dp)) {
                    val w = 2.6.dp.toPx()
                    drawLine(c.accent, Offset(size.width / 2, 0f), Offset(size.width / 2, size.height), w, StrokeCap.Round)
                    drawLine(c.accent, Offset(0f, size.height / 2), Offset(size.width, size.height / 2), w, StrokeCap.Round)
                }
            }
        }
    }
}

@Composable
fun LargeTitle(text: String) {
    IText(
        text, 34.sp, weight = FontWeight.Bold,
        modifier = Modifier.padding(start = 20.dp, top = 2.dp, bottom = 8.dp)
    )
}

@Composable
fun Chevron(color: Color = LocalIos.current.secondary) {
    Canvas(Modifier.size(width = 8.dp, height = 14.dp)) {
        val w = 2.dp.toPx()
        drawLine(color, Offset(w / 2, w / 2), Offset(size.width - w / 2, size.height / 2), w, StrokeCap.Round)
        drawLine(color, Offset(size.width - w / 2, size.height / 2), Offset(w / 2, size.height - w / 2), w, StrokeCap.Round)
    }
}

@Composable
fun CheckMark(color: Color = LocalIos.current.accent) {
    Canvas(Modifier.size(18.dp)) {
        val w = 2.4.dp.toPx()
        drawLine(color, Offset(w, size.height * 0.55f), Offset(size.width * 0.38f, size.height * 0.85f), w, StrokeCap.Round)
        drawLine(color, Offset(size.width * 0.38f, size.height * 0.85f), Offset(size.width - w, size.height * 0.12f), w, StrokeCap.Round)
    }
}

// ----------------------------------------------------------------- switch
@Composable
fun IosSwitch(checked: Boolean, onCheckedChange: (Boolean) -> Unit) {
    val c = LocalIos.current
    val x by animateDpAsState(if (checked) 20.dp else 0.dp, tween(200), label = "knob")
    val track by animateColorAsState(if (checked) c.green else c.fill, tween(200), label = "track")
    Box(
        Modifier
            .size(width = 51.dp, height = 31.dp)
            .clip(RoundedCornerShape(50))
            .background(track)
            .tap { onCheckedChange(!checked) }
            .padding(2.dp)
    ) {
        Box(
            Modifier
                .offset(x = x)
                .size(27.dp)
                .shadow(2.dp, CircleShape)
                .background(Color.White, CircleShape)
        )
    }
}

// -------------------------------------------------------- round buttons
@Composable
fun RoundButton(
    text: String,
    bg: Color,
    fg: Color,
    enabled: Boolean = true,
    onClick: () -> Unit
) {
    val a = if (enabled) 1f else 0.45f
    Box(
        Modifier
            .size(94.dp)
            .border(1.5.dp, bg.copy(alpha = 0.35f * a), CircleShape)
            .padding(5.dp)
            .clip(CircleShape)
            .background(bg.copy(alpha = a))
            .tap(enabled = enabled, onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        IText(text, 17.sp, fg.copy(alpha = a))
    }
}

// ---------------------------------------------------------- swipe to delete
@Composable
fun SwipeRow(
    revealed: Boolean,
    onRevealChange: (Boolean) -> Unit,
    onDelete: () -> Unit,
    modifier: Modifier = Modifier,
    content: @Composable () -> Unit
) {
    val c = LocalIos.current
    val maxPx = with(LocalDensity.current) { 88.dp.toPx() }
    val anim = remember { Animatable(0f) }
    var dragging by remember { mutableStateOf(false) }
    var drag by remember { mutableFloatStateOf(0f) }

    LaunchedEffect(revealed, dragging, maxPx) {
        if (!dragging) anim.animateTo(if (revealed) -maxPx else 0f, tween(220))
    }
    val offset = if (dragging) drag else anim.value

    Box(modifier.fillMaxWidth().clipToBounds()) {
        Box(
            Modifier.matchParentSize().background(c.red),
            contentAlignment = Alignment.CenterEnd
        ) {
            Box(
                Modifier.width(88.dp).fillMaxHeight().tap(onClick = onDelete),
                contentAlignment = Alignment.Center
            ) { IText("Delete", 17.sp, Color.White) }
        }
        Box(
            Modifier
                .offset { IntOffset(offset.roundToInt(), 0) }
                .background(c.bg)
                .draggable(
                    orientation = Orientation.Horizontal,
                    state = rememberDraggableState { d -> drag = (drag + d).coerceIn(-maxPx * 1.8f, 0f) },
                    onDragStarted = { drag = anim.value; dragging = true },
                    onDragStopped = {
                        anim.snapTo(drag)
                        if (drag < -maxPx * 1.5f) onDelete() else onRevealChange(drag < -maxPx / 2)
                        dragging = false
                    }
                )
        ) { content() }
    }
}

@Composable
fun MinusButton(onClick: () -> Unit) {
    val c = LocalIos.current
    Box(
        Modifier.size(24.dp).clip(CircleShape).background(c.red).tap(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Box(Modifier.size(width = 12.dp, height = 2.5.dp).background(Color.White, RoundedCornerShape(2.dp)))
    }
}

// ------------------------------------------------------------ wheel picker
/**
 * iOS-style wheel. The highlight band is drawn by the caller ([WheelGroup]).
 * The wheel is the source of truth after creation; [initialIndex] only positions it once.
 */
@Composable
fun WheelPicker(
    items: List<String>,
    initialIndex: Int,
    onSelected: (Int) -> Unit,
    modifier: Modifier = Modifier,
    infinite: Boolean = false,
    width: Dp = 72.dp,
    textSize: TextUnit = 26.sp,
    contentAlignment: Alignment = Alignment.Center
) {
    val c = LocalIos.current
    val rowH = 44.dp
    val n = items.size
    val repeat = if (infinite) 400 else 1
    val total = n * repeat
    val start = if (infinite) (repeat / 2) * n + initialIndex else initialIndex
    val state = rememberLazyListState(initialFirstVisibleItemIndex = start)
    val fling = rememberSnapFlingBehavior(lazyListState = state)
    val haptic = LocalHapticFeedback.current
    val rowPx = with(LocalDensity.current) { rowH.toPx() }
    val center by remember {
        derivedStateOf {
            (state.firstVisibleItemIndex + if (state.firstVisibleItemScrollOffset > rowPx / 2) 1 else 0)
                .coerceIn(0, total - 1)
        }
    }
    var first by remember { mutableStateOf(true) }
    LaunchedEffect(center) {
        onSelected(center % n)
        if (first) first = false else haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
    }

    LazyColumn(
        state = state,
        flingBehavior = fling,
        contentPadding = PaddingValues(vertical = rowH * 2),
        modifier = modifier.width(width).height(rowH * 5)
    ) {
        items(count = total) { i ->
            val d = abs(i - center)
            val alpha = when (d) { 0 -> 1f; 1 -> 0.5f; 2 -> 0.22f; else -> 0.1f }
            Box(
                Modifier.fillMaxWidth().height(rowH).padding(horizontal = 6.dp),
                contentAlignment = contentAlignment
            ) {
                IText(items[i % n], textSize, c.label.copy(alpha = alpha), tnum = true)
            }
        }
    }
}

@Composable
fun WheelGroup(content: @Composable () -> Unit) {
    val c = LocalIos.current
    Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
        Box(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp)
                .height(44.dp)
                .background(c.fill.copy(alpha = 0.6f), RoundedCornerShape(10.dp))
        )
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center) {
            content()
        }
    }
}

// --------------------------------------------------------------- tab icons
/** kind: 0 world clock, 1 alarm, 2 stopwatch, 3 timer. */
@Composable
fun TabGlyph(kind: Int, tint: Color, filled: Boolean, cut: Color, modifier: Modifier = Modifier.size(28.dp)) {
    Canvas(modifier) {
        val s = size.width
        val w = s * 0.075f
        val st = Stroke(width = w, cap = StrokeCap.Round)
        val ink = if (filled) cut else tint
        when (kind) {
            0 -> {
                val r = s * 0.44f
                val ctr = Offset(s / 2, s / 2)
                if (filled) drawCircle(tint, r, ctr) else drawCircle(tint, r - w / 2, ctr, style = st)
                drawOval(ink, Offset(s / 2 - s * 0.17f, s / 2 - r + w), Size(s * 0.34f, 2 * r - 2 * w), style = st)
                drawLine(ink, Offset(s / 2 - r + w, s / 2), Offset(s / 2 + r - w, s / 2), w, StrokeCap.Round)
                drawLine(ink, Offset(s * 0.22f, s * 0.3f), Offset(s * 0.78f, s * 0.3f), w, StrokeCap.Round)
                drawLine(ink, Offset(s * 0.22f, s * 0.7f), Offset(s * 0.78f, s * 0.7f), w, StrokeCap.Round)
            }
            1 -> {
                val r = s * 0.34f
                val ctr = Offset(s / 2, s * 0.57f)
                if (filled) drawCircle(tint, r, ctr) else drawCircle(tint, r - w / 2, ctr, style = st)
                drawLine(ink, ctr, Offset(ctr.x, ctr.y - r * 0.6f), w, StrokeCap.Round)
                drawLine(ink, ctr, Offset(ctr.x + r * 0.45f, ctr.y + r * 0.25f), w, StrokeCap.Round)
                drawArc(tint, 180f, 90f, false, Offset(s * 0.02f, s * 0.02f), Size(s * 0.36f, s * 0.36f), style = st)
                drawArc(tint, 270f, 90f, false, Offset(s * 0.62f, s * 0.02f), Size(s * 0.36f, s * 0.36f), style = st)
            }
            2 -> {
                val r = s * 0.36f
                val ctr = Offset(s / 2, s * 0.58f)
                if (filled) drawCircle(tint, r, ctr) else drawCircle(tint, r - w / 2, ctr, style = st)
                drawLine(tint, Offset(s * 0.4f, s * 0.07f), Offset(s * 0.6f, s * 0.07f), w, StrokeCap.Round)
                drawLine(tint, Offset(s / 2, s * 0.07f), Offset(s / 2, s * 0.16f), w, StrokeCap.Round)
                drawLine(tint, Offset(s * 0.82f, s * 0.2f), Offset(s * 0.9f, s * 0.28f), w, StrokeCap.Round)
                drawLine(ink, ctr, Offset(ctr.x + r * 0.45f, ctr.y - r * 0.5f), w, StrokeCap.Round)
            }
            else -> {
                val r = s * 0.36f
                val ctr = Offset(s / 2, s * 0.58f)
                if (filled) drawCircle(tint, r, ctr) else drawCircle(tint, r - w / 2, ctr, style = st)
                drawLine(tint, Offset(s * 0.4f, s * 0.07f), Offset(s * 0.6f, s * 0.07f), w, StrokeCap.Round)
                drawLine(tint, Offset(s / 2, s * 0.07f), Offset(s / 2, s * 0.16f), w, StrokeCap.Round)
                drawLine(ink, ctr, Offset(ctr.x, ctr.y - r * 0.62f), w, StrokeCap.Round)
                drawLine(ink, ctr, Offset(ctr.x + r * 0.45f, ctr.y + r * 0.25f), w, StrokeCap.Round)
            }
        }
    }
}
