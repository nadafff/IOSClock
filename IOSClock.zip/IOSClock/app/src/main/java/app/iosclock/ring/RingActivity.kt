package app.iosclock.ring

import android.app.KeyguardManager
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.iosclock.ui.IText
import app.iosclock.ui.IosTheme
import app.iosclock.ui.LocalIos
import app.iosclock.ui.RoundButton
import kotlinx.coroutines.delay
import java.text.DateFormat
import java.util.Date

/** Full-screen "alarm is ringing" page shown over the lock screen. */
class RingActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        if (Build.VERSION.SDK_INT >= 27) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
        } else {
            @Suppress("DEPRECATION")
            window.addFlags(
                WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
                    WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON
            )
        }
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        getSystemService(KeyguardManager::class.java)?.requestDismissKeyguard(this, null)

        setContent {
            IosTheme {
                val info by RingService.ringing.collectAsState()
                val current = info
                if (current == null) {
                    LaunchedEffect(Unit) { finish() }
                } else {
                    RingScreen(
                        label = current.label,
                        canSnooze = current.canSnooze,
                        onStop = { send(RingService.ACTION_STOP); finish() },
                        onSnooze = { send(RingService.ACTION_SNOOZE); finish() }
                    )
                }
            }
        }
    }

    private fun send(action: String) {
        startService(Intent(this, RingService::class.java).setAction(action))
    }
}

@Composable
private fun RingScreen(label: String, canSnooze: Boolean, onStop: () -> Unit, onSnooze: () -> Unit) {
    val c = LocalIos.current
    val ctx = LocalContext.current
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) {
        while (true) {
            now = System.currentTimeMillis()
            delay(1000)
        }
    }
    val time = DateFormat.getTimeInstance(DateFormat.SHORT).format(Date(now))

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        Column(
            Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(horizontal = 24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(Modifier.height(96.dp))
            IText(label, 28.sp, Color.White, FontWeight.Medium, align = TextAlign.Center)
            Spacer(Modifier.height(8.dp))
            IText(time, 84.sp, Color.White, FontWeight.Light, tnum = true)
            Spacer(Modifier.weight(1f))
            Row(Modifier.padding(bottom = 48.dp), horizontalArrangement = Arrangement.spacedBy(48.dp)) {
                if (canSnooze) RoundButton("Snooze", c.accent, Color.White, onClick = onSnooze)
                RoundButton("Stop", Color(0xFF333336), Color.White, onClick = onStop)
            }
        }
    }
}
