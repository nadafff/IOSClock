package app.iosclock.ui

import android.media.Ringtone
import android.media.RingtoneManager
import android.net.Uri
import android.text.format.DateFormat
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandHorizontally
import androidx.compose.animation.shrinkHorizontally
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.iosclock.ClockViewModel
import app.iosclock.data.AlarmItem
import app.iosclock.data.SoundRepo
import java.time.ZonedDateTime
import java.util.Locale

// Display order: Sunday first (like iOS in en-US). Values are ISO day numbers.
private val DAY_ORDER = listOf(7, 1, 2, 3, 4, 5, 6)
private val DAY_FULL = mapOf(1 to "Monday", 2 to "Tuesday", 3 to "Wednesday", 4 to "Thursday", 5 to "Friday", 6 to "Saturday", 7 to "Sunday")
private val DAY_SHORT = mapOf(1 to "Mon", 2 to "Tue", 3 to "Wed", 4 to "Thu", 5 to "Fri", 6 to "Sat", 7 to "Sun")

fun repeatText(days: Set<Int>): String = when {
    days.isEmpty() -> "Never"
    days.size == 7 -> "Every day"
    days == setOf(1, 2, 3, 4, 5) -> "Weekdays"
    days == setOf(6, 7) -> "Weekends"
    else -> DAY_ORDER.filter { it in days }.joinToString(", ") { DAY_SHORT.getValue(it) }
}

// ---------------------------------------------------------------- alarm list
@Composable
fun AlarmScreen(vm: ClockViewModel, onAdd: () -> Unit, onEdit: (AlarmItem) -> Unit) {
    val c = LocalIos.current
    val ctx = LocalContext.current
    val is24 = remember { DateFormat.is24HourFormat(ctx) }
    var editing by remember { mutableStateOf(false) }
    var revealedId by remember { mutableStateOf<Int?>(null) }

    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        NavBar(
            left = if (vm.alarms.isEmpty()) null else if (editing) "Done" else "Edit",
            onLeft = { editing = !editing; revealedId = null },
            onPlus = onAdd
        )
        LargeTitle("Alarm")
        if (vm.alarms.isNotEmpty()) {
            IText("Other", 22.sp, c.label, FontWeight.Bold, modifier = Modifier.padding(start = 20.dp, bottom = 6.dp))
        }
        Hairline()
        LazyColumn(Modifier.fillMaxSize()) {
            items(vm.alarms, key = { it.id }) { a ->
                SwipeRow(
                    revealed = revealedId == a.id,
                    onRevealChange = { revealedId = if (it) a.id else null },
                    onDelete = { vm.deleteAlarm(a.id); revealedId = null }
                ) {
                    Column(Modifier.background(c.bg)) {
                        Row(
                            Modifier
                                .fillMaxWidth()
                                .tap { if (editing || revealedId != a.id) onEdit(a) else revealedId = null }
                                .padding(horizontal = 20.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            AnimatedVisibility(editing, enter = expandHorizontally(), exit = shrinkHorizontally()) {
                                Row {
                                    MinusButton { revealedId = if (revealedId == a.id) null else a.id }
                                    Spacer(Modifier.width(14.dp))
                                }
                            }
                            Column(Modifier.weight(1f)) {
                                val ink = if (a.enabled) c.label else c.secondary
                                val t = ZonedDateTime.now().withHour(a.hour).withMinute(a.minute)
                                val (main, suffix) = timeParts(t, is24)
                                Row {
                                    IText(main, 52.sp, ink, FontWeight.Light, tnum = true, modifier = Modifier.alignByBaseline())
                                    if (suffix.isNotEmpty()) {
                                        IText(" $suffix", 24.sp, ink, FontWeight.Light, modifier = Modifier.alignByBaseline())
                                    }
                                }
                                val sub = listOf(a.label.ifBlank { "Alarm" }, repeatText(a.days).takeIf { a.days.isNotEmpty() } ?: "")
                                    .filter { it.isNotEmpty() }.joinToString(", ")
                                IText(sub, 15.sp, if (a.enabled) c.label else c.secondary, maxLines = 1)
                            }
                            if (editing) Chevron() else IosSwitch(a.enabled) { vm.toggleAlarm(a.id, it) }
                        }
                        Hairline(startPadding = 20.dp)
                    }
                }
            }
        }
    }
}

// -------------------------------------------------------------- alarm editor
private enum class EditorPage { MAIN, REPEAT, LABEL, SOUND }

@Composable
fun AlarmEditor(
    initial: AlarmItem,
    isNew: Boolean,
    onSave: (AlarmItem) -> Unit,
    onDelete: () -> Unit,
    onClose: () -> Unit
) {
    val c = LocalIos.current
    val ctx = LocalContext.current
    val is24 = remember { DateFormat.is24HourFormat(ctx) }

    var hour24 by remember { mutableIntStateOf(initial.hour) }
    var h12 by remember { mutableIntStateOf(if (initial.hour % 12 == 0) 12 else initial.hour % 12) }
    var pm by remember { mutableIntStateOf(if (initial.hour >= 12) 1 else 0) }
    var minute by remember { mutableIntStateOf(initial.minute) }
    var days by remember { mutableStateOf(initial.days) }
    var label by remember { mutableStateOf(initial.label) }
    var sound by remember { mutableStateOf(initial.soundUri) }
    var snooze by remember { mutableStateOf(initial.snooze) }
    var page by remember { mutableStateOf(EditorPage.MAIN) }

    BackHandler { if (page != EditorPage.MAIN) page = EditorPage.MAIN else onClose() }

    when (page) {
        EditorPage.REPEAT -> RepeatPage(days, { days = it }) { page = EditorPage.MAIN }
        EditorPage.LABEL -> LabelPage(label, { label = it }) { page = EditorPage.MAIN }
        EditorPage.SOUND -> SoundPickerPage("Sound", sound, { sound = it }) { page = EditorPage.MAIN }
        EditorPage.MAIN -> Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()) {
            Row(
                Modifier.fillMaxWidth().height(52.dp).padding(horizontal = 20.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                IText("Cancel", 17.sp, c.accent, modifier = Modifier.tap(onClick = onClose))
                IText(if (isNew) "Add Alarm" else "Edit Alarm", 17.sp, c.label, FontWeight.SemiBold)
                IText("Save", 17.sp, c.accent, FontWeight.SemiBold, modifier = Modifier.tap {
                    val h = if (is24) hour24 else (h12 % 12) + if (pm == 1) 12 else 0
                    onSave(initial.copy(hour = h, minute = minute, days = days, label = label, soundUri = sound, snooze = snooze, enabled = true))
                })
            }
            Spacer(Modifier.height(16.dp))
            WheelGroup {
                if (is24) {
                    WheelPicker(List(24) { String.format(Locale.US, "%02d", it) }, initial.hour, { hour24 = it }, infinite = true, width = 84.dp)
                    WheelPicker(List(60) { String.format(Locale.US, "%02d", it) }, initial.minute, { minute = it }, infinite = true, width = 84.dp)
                } else {
                    WheelPicker(List(12) { (it + 1).toString() }, h12 - 1, { h12 = it + 1 }, infinite = true, width = 84.dp)
                    WheelPicker(List(60) { String.format(Locale.US, "%02d", it) }, initial.minute, { minute = it }, infinite = true, width = 84.dp)
                    WheelPicker(listOf("AM", "PM"), pm, { pm = it }, width = 84.dp)
                }
            }
            Spacer(Modifier.height(20.dp))
            Column(
                Modifier.padding(horizontal = 16.dp).clip(RoundedCornerShape(10.dp)).background(c.card)
            ) {
                SettingRow("Repeat", repeatText(days)) { page = EditorPage.REPEAT }
                Hairline(startPadding = 16.dp)
                SettingRow("Label", label.ifBlank { "Alarm" }) { page = EditorPage.LABEL }
                Hairline(startPadding = 16.dp)
                SettingRow("Sound", SoundRepo.titleFor(ctx, sound)) { page = EditorPage.SOUND }
                Hairline(startPadding = 16.dp)
                Row(
                    Modifier.fillMaxWidth().height(48.dp).padding(horizontal = 16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IText("Snooze", 17.sp, c.label, modifier = Modifier.weight(1f))
                    IosSwitch(snooze) { snooze = it }
                }
            }
            if (!isNew) {
                Spacer(Modifier.height(24.dp))
                Box(
                    Modifier
                        .padding(horizontal = 16.dp)
                        .fillMaxWidth()
                        .height(48.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(c.card)
                        .tap(onClick = onDelete),
                    contentAlignment = Alignment.Center
                ) { IText("Delete Alarm", 17.sp, c.red) }
            }
        }
    }
}

@Composable
private fun SettingRow(title: String, value: String, onClick: () -> Unit) {
    val c = LocalIos.current
    Row(
        Modifier.fillMaxWidth().height(48.dp).tap(onClick = onClick).padding(horizontal = 16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        IText(title, 17.sp, c.label)
        Spacer(Modifier.weight(1f))
        IText(value, 17.sp, c.secondary, maxLines = 1, modifier = Modifier.padding(end = 8.dp))
        Chevron()
    }
}

@Composable
private fun SubPageHeader(title: String, onBack: () -> Unit) {
    val c = LocalIos.current
    Row(
        Modifier.fillMaxWidth().height(52.dp).padding(horizontal = 20.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        IText("‹ Back", 17.sp, c.accent, modifier = Modifier.tap(onClick = onBack))
        IText(title, 17.sp, c.label, FontWeight.SemiBold, align = TextAlign.Center, modifier = Modifier.weight(1f))
        Spacer(Modifier.width(48.dp))
    }
}

@Composable
private fun RepeatPage(days: Set<Int>, onChange: (Set<Int>) -> Unit, onBack: () -> Unit) {
    val c = LocalIos.current
    Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()) {
        SubPageHeader("Repeat", onBack)
        Spacer(Modifier.height(12.dp))
        Column(Modifier.padding(horizontal = 16.dp).clip(RoundedCornerShape(10.dp)).background(c.card)) {
            DAY_ORDER.forEachIndexed { i, d ->
                Row(
                    Modifier.fillMaxWidth().height(48.dp).tap {
                        onChange(if (d in days) days - d else days + d)
                    }.padding(horizontal = 16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IText("Every ${DAY_FULL.getValue(d)}", 17.sp, c.label, modifier = Modifier.weight(1f))
                    if (d in days) CheckMark()
                }
                if (i < DAY_ORDER.lastIndex) Hairline(startPadding = 16.dp)
            }
        }
    }
}

@Composable
private fun LabelPage(label: String, onChange: (String) -> Unit, onBack: () -> Unit) {
    val c = LocalIos.current
    val focus = remember { FocusRequester() }
    androidx.compose.runtime.LaunchedEffect(Unit) { runCatching { focus.requestFocus() } }
    Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().imePadding()) {
        SubPageHeader("Label", onBack)
        Spacer(Modifier.height(12.dp))
        Box(
            Modifier
                .padding(horizontal = 16.dp)
                .fillMaxWidth()
                .clip(RoundedCornerShape(10.dp))
                .background(c.card)
                .padding(horizontal = 16.dp, vertical = 14.dp)
        ) {
            if (label.isEmpty()) IText("Alarm", 17.sp, c.secondary)
            BasicTextField(
                value = label,
                onValueChange = { onChange(it.take(40)) },
                singleLine = true,
                textStyle = TextStyle(color = c.label, fontSize = 17.sp),
                cursorBrush = SolidColor(c.accent),
                modifier = Modifier.fillMaxWidth().focusRequester(focus)
            )
        }
    }
}

// --------------------------------------------------------------- sound page
@Composable
fun SoundPickerPage(title: String, selected: String, onSelect: (String) -> Unit, onBack: () -> Unit) {
    val c = LocalIos.current
    val ctx = LocalContext.current
    val sounds = remember { SoundRepo.list(ctx) }
    val holder = remember { arrayOfNulls<Ringtone>(1) }
    DisposableEffect(Unit) { onDispose { holder[0]?.stop() } }

    Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()) {
        SubPageHeader(title, onBack)
        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp)) {
            item {
                Column(Modifier.clip(RoundedCornerShape(10.dp)).background(c.card)) {
                    sounds.forEachIndexed { i, s ->
                        Row(
                            Modifier.fillMaxWidth().height(48.dp).tap {
                                onSelect(s.uri)
                                holder[0]?.stop()
                                holder[0] = runCatching { RingtoneManager.getRingtone(ctx, Uri.parse(s.uri)) }.getOrNull()
                                holder[0]?.play()
                            }.padding(horizontal = 16.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            IText(s.title, 17.sp, c.label, maxLines = 1, modifier = Modifier.weight(1f))
                            if (s.uri == selected || (selected.isEmpty() && i == 0)) CheckMark()
                        }
                        if (i < sounds.lastIndex) Hairline(startPadding = 16.dp)
                    }
                }
            }
        }
    }
}
