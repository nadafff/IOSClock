package app.iosclock.ring

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import androidx.core.app.NotificationCompat
import app.iosclock.R
import app.iosclock.alarm.AlarmScheduler
import app.iosclock.data.ClockRepository
import kotlinx.coroutines.flow.MutableStateFlow

data class RingInfo(val kind: Int, val alarmId: Int, val label: String, val canSnooze: Boolean)

/** Foreground service that plays the alarm/timer sound until the user stops or snoozes it. */
class RingService : Service() {

    private var player: MediaPlayer? = null
    private val handler = Handler(Looper.getMainLooper())
    private val autoStop = Runnable { shutdown() }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> shutdown()
            ACTION_SNOOZE -> {
                val info = ringing.value
                if (info != null && info.kind == KIND_ALARM && info.canSnooze) {
                    AlarmScheduler.scheduleSnooze(this, info.alarmId)
                }
                shutdown()
            }
            else -> begin(intent)
        }
        return START_NOT_STICKY
    }

    private fun begin(intent: Intent?) {
        val kind = intent?.getIntExtra(EXTRA_KIND, KIND_ALARM) ?: KIND_ALARM
        val id = intent?.getIntExtra(EXTRA_ALARM_ID, -1) ?: -1
        val repo = ClockRepository.get(this)
        val alarm = if (kind == KIND_ALARM) repo.loadAlarms().firstOrNull { it.id == id } else null

        val label = if (kind == KIND_TIMER) "Timer" else (alarm?.label?.ifBlank { "Alarm" } ?: "Alarm")
        val sound = if (kind == KIND_TIMER) repo.loadTimer().soundUri
        else alarm?.soundUri ?: ClockRepository.defaultSound()
        val canSnooze = kind == KIND_ALARM && (alarm?.snooze ?: true)

        ringing.value = RingInfo(kind, id, label, canSnooze)
        createChannel()
        val notification = buildNotification(label, canSnooze)
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIF_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
        } else {
            startForeground(NOTIF_ID, notification)
        }
        startSound(sound)
        startVibration()
        handler.removeCallbacks(autoStop)
        handler.postDelayed(autoStop, AUTO_STOP_MS)
    }

    private fun buildNotification(label: String, canSnooze: Boolean): Notification {
        val flags = PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        val ringIntent = Intent(this, RingActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        val full = PendingIntent.getActivity(this, 1, ringIntent, flags)
        val stop = PendingIntent.getService(
            this, 2, Intent(this, RingService::class.java).setAction(ACTION_STOP), flags
        )
        val b = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_stat_alarm)
            .setContentTitle(label)
            .setContentText(if (label == "Timer") "Timer ended" else "Alarm")
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setOngoing(true)
            .setAutoCancel(false)
            .setContentIntent(full)
            .setFullScreenIntent(full, true)
            .addAction(0, "Stop", stop)
        if (canSnooze) {
            val snooze = PendingIntent.getService(
                this, 3, Intent(this, RingService::class.java).setAction(ACTION_SNOOZE), flags
            )
            b.addAction(0, "Snooze", snooze)
        }
        return b.build()
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT < 26) return
        val nm = getSystemService(NotificationManager::class.java)
        if (nm.getNotificationChannel(CHANNEL_ID) == null) {
            val ch = NotificationChannel(CHANNEL_ID, "Alarms & Timers", NotificationManager.IMPORTANCE_HIGH)
            ch.setSound(null, null) // sound is played by this service itself
            ch.enableVibration(false)
            ch.lockscreenVisibility = Notification.VISIBILITY_PUBLIC
            nm.createNotificationChannel(ch)
        }
    }

    private fun startSound(uriString: String) {
        stopSound()
        val attrs = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_ALARM)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
            .build()
        val candidates = listOf(uriString, ClockRepository.defaultSound()).filter { it.isNotEmpty() }
        for (u in candidates) {
            try {
                val mp = MediaPlayer()
                mp.setAudioAttributes(attrs)
                mp.setWakeMode(this, PowerManager.PARTIAL_WAKE_LOCK)
                mp.setDataSource(this, Uri.parse(u))
                mp.isLooping = true
                mp.prepare()
                mp.start()
                player = mp
                return
            } catch (_: Exception) {
                player?.release()
                player = null
            }
        }
        // Last resort: system default notification tone
        try {
            val mp = MediaPlayer()
            mp.setAudioAttributes(attrs)
            mp.setDataSource(this, RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION))
            mp.isLooping = true
            mp.prepare()
            mp.start()
            player = mp
        } catch (_: Exception) {
        }
    }

    private fun stopSound() {
        player?.let {
            runCatching { if (it.isPlaying) it.stop() }
            it.release()
        }
        player = null
    }

    private fun vibrator(): Vibrator? =
        if (Build.VERSION.SDK_INT >= 31) {
            getSystemService(VibratorManager::class.java)?.defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
        }

    private fun startVibration() {
        vibrator()?.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 700, 500), 0))
    }

    private fun shutdown() {
        handler.removeCallbacks(autoStop)
        stopSound()
        vibrator()?.cancel()
        ringing.value = null
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        handler.removeCallbacks(autoStop)
        stopSound()
        vibrator()?.cancel()
        ringing.value = null
        super.onDestroy()
    }

    companion object {
        const val ACTION_STOP = "app.iosclock.action.STOP"
        const val ACTION_SNOOZE = "app.iosclock.action.SNOOZE"
        const val EXTRA_KIND = "kind"
        const val EXTRA_ALARM_ID = "alarm_id"
        const val KIND_ALARM = 0
        const val KIND_TIMER = 1
        private const val CHANNEL_ID = "ring"
        private const val NOTIF_ID = 4242
        private const val AUTO_STOP_MS = 10 * 60 * 1000L

        /** Non-null while something is ringing; observed by [RingActivity]. */
        val ringing = MutableStateFlow<RingInfo?>(null)
    }
}
