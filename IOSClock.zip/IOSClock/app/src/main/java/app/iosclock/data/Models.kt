package app.iosclock.data

/** days: ISO day-of-week values, 1 = Monday ... 7 = Sunday. Empty = one-shot alarm. */
data class AlarmItem(
    val id: Int,
    val hour: Int,
    val minute: Int,
    val days: Set<Int>,
    val label: String,
    val soundUri: String,
    val snooze: Boolean,
    val enabled: Boolean
)

data class LapItem(val number: Int, val lapMs: Long, val totalMs: Long)

data class StopwatchState(
    val running: Boolean = false,
    /** SystemClock.elapsedRealtime() at the moment the current run started. */
    val startedAt: Long = 0L,
    val accumulatedMs: Long = 0L,
    val laps: List<LapItem> = emptyList()
) {
    fun elapsed(nowElapsed: Long): Long =
        accumulatedMs + if (running) (nowElapsed - startedAt).coerceAtLeast(0L) else 0L
}

enum class TimerStatus { IDLE, RUNNING, PAUSED }

data class TimerState(
    val status: TimerStatus = TimerStatus.IDLE,
    /** Last configured duration (also the ring's full length while running). */
    val totalMs: Long = 5 * 60_000L,
    /** Wall-clock end time, valid while RUNNING. */
    val endAt: Long = 0L,
    /** Remaining time, valid while PAUSED. */
    val remainingMs: Long = 0L,
    val soundUri: String = ""
)

data class City(val name: String, val country: String, val zone: String) {
    val key: String get() = "$name|$country|$zone"
}
