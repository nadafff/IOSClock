package app.iosclock.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.tween
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import app.iosclock.ClockViewModel
import app.iosclock.data.AlarmItem
import app.iosclock.data.ClockRepository
import java.time.LocalTime

private val TAB_NAMES = listOf("World Clock", "Alarm", "Stopwatch", "Timer")

@Composable
fun ClockRoot(vm: ClockViewModel = viewModel()) {
    val c = LocalIos.current
    var tab by rememberSaveable { mutableIntStateOf(0) }

    var editorAlarm by remember { mutableStateOf<AlarmItem?>(null) }
    var editorIsNew by remember { mutableStateOf(false) }
    var editorVisible by remember { mutableStateOf(false) }
    var cityVisible by remember { mutableStateOf(false) }
    var timerSoundVisible by remember { mutableStateOf(false) }

    fun openEditor(a: AlarmItem, isNew: Boolean) {
        editorAlarm = a
        editorIsNew = isNew
        editorVisible = true
    }

    Box(Modifier.fillMaxSize().background(c.bg)) {
        Column(Modifier.fillMaxSize()) {
            Box(Modifier.weight(1f).fillMaxWidth()) {
                Crossfade(targetState = tab, animationSpec = tween(180), label = "tabs") { t ->
                    when (t) {
                        0 -> WorldClockScreen(vm, onAdd = { cityVisible = true })
                        1 -> AlarmScreen(
                            vm,
                            onAdd = {
                                val now = LocalTime.now()
                                openEditor(
                                    AlarmItem(
                                        id = vm.newAlarmId(), hour = now.hour, minute = now.minute,
                                        days = emptySet(), label = "", soundUri = ClockRepository.defaultSound(),
                                        snooze = true, enabled = true
                                    ),
                                    true
                                )
                            },
                            onEdit = { openEditor(it, false) }
                        )
                        2 -> StopwatchScreen(vm)
                        else -> TimerScreen(vm, onPickSound = { timerSoundVisible = true })
                    }
                }
            }
            TabBar(tab) { tab = it }
        }

        SlideUp(cityVisible) {
            CityPicker(
                onPick = { vm.addCity(it); cityVisible = false },
                onCancel = { cityVisible = false }
            )
        }

        SlideUp(editorVisible) {
            editorAlarm?.let { a ->
                AlarmEditor(
                    initial = a,
                    isNew = editorIsNew,
                    onSave = { vm.saveAlarm(it); editorVisible = false },
                    onDelete = { vm.deleteAlarm(a.id); editorVisible = false },
                    onClose = { editorVisible = false }
                )
            }
        }

        SlideUp(timerSoundVisible) {
            BackHandler { timerSoundVisible = false }
            Box(Modifier.fillMaxSize().background(c.bg)) {
                SoundPickerPage(
                    title = "When Timer Ends",
                    selected = vm.timer.soundUri,
                    onSelect = { vm.setTimerSound(it) },
                    onBack = { timerSoundVisible = false }
                )
            }
        }
    }
}

@Composable
private fun SlideUp(visible: Boolean, content: @Composable () -> Unit) {
    AnimatedVisibility(
        visible = visible,
        enter = slideInVertically(tween(350)) { it },
        exit = slideOutVertically(tween(300)) { it }
    ) {
        Box(Modifier.fillMaxSize().background(LocalIos.current.bg)) { content() }
    }
}

@Composable
private fun TabBar(selected: Int, onSelect: (Int) -> Unit) {
    val c = LocalIos.current
    Column(Modifier.fillMaxWidth().background(c.tabBar)) {
        Hairline()
        Row(Modifier.fillMaxWidth().height(56.dp)) {
            TAB_NAMES.forEachIndexed { i, name ->
                val tint = if (selected == i) c.accent else c.secondary
                Column(
                    Modifier.weight(1f).fillMaxHeight().tap { onSelect(i) },
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = androidx.compose.foundation.layout.Arrangement.Center
                ) {
                    TabGlyph(i, tint, filled = selected == i, cut = c.tabBar)
                    Spacer(Modifier.height(2.dp))
                    IText(name, 10.sp, tint)
                }
            }
        }
        Spacer(Modifier.navigationBarsPadding())
    }
}
