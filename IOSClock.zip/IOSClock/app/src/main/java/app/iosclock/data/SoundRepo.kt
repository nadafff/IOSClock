package app.iosclock.data

import android.content.Context
import android.media.RingtoneManager
import android.net.Uri

data class SoundItem(val title: String, val uri: String)

object SoundRepo {
    fun list(ctx: Context): List<SoundItem> {
        val out = mutableListOf(SoundItem("Default", ClockRepository.defaultSound()))
        try {
            val rm = RingtoneManager(ctx)
            rm.setType(RingtoneManager.TYPE_ALARM or RingtoneManager.TYPE_NOTIFICATION or RingtoneManager.TYPE_RINGTONE)
            val cur = rm.cursor
            while (cur.moveToNext()) {
                val title = cur.getString(RingtoneManager.TITLE_COLUMN_INDEX) ?: continue
                out += SoundItem(title, rm.getRingtoneUri(cur.position).toString())
            }
        } catch (_: Exception) {
        }
        return out.distinctBy { it.uri }
    }

    fun titleFor(ctx: Context, uri: String): String {
        if (uri.isEmpty() || uri == ClockRepository.defaultSound()) return "Default"
        return runCatching { RingtoneManager.getRingtone(ctx, Uri.parse(uri)).getTitle(ctx) }
            .getOrNull() ?: "Default"
    }
}
