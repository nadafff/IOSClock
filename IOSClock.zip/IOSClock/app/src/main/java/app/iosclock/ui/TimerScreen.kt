package app.iosclock.ui

import android.text.format.DateFormat
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.background
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.iosclock.ClockViewModel
import app.iosclock.data.SoundRepo
import app.iosclock.data.TimerStatus
import kotlinx.coroutines.delay
import java.time.Instant
import java.time.ZoneId
import java.util.Locale
import kotlin.math.ceil

@Composable
fun TimerScreen(vm: ClockViewModel, onPickSound: () -> Unit) {
    when (vm.timer.status) {
        TimerStatus.IDLE -> TimerSetup(vm, onPickSound)
        else -> TimerRunning(vm)
    }
}

@Composable
private fun TimerSetup(vm: ClockViewModel, onPickSound: () -> Unit) {
    val c = LocalIos.current
    val ctx = LocalContext.current
    val initial = vm.timer.totalMs / 1000L
    var h by remember { mutableIntStateOf((initial / 3600).toInt().coerceIn(0, 23)) }
    var m by remember { mutableIntStateOf(((initial % 3600) / 60).toInt()) }
    var s by remember { mutableIntStateOf((initial % 60).toInt()) }
    val totalMs = (h * 3600L + m * 60L + s) * 1000L
    LaunchedEffect(totalMs) { vm.rememberTimerDuration(totalMs) }

    Column(Modifier.fillMaxSize().statusBarsPadding(), horizontalAlignment = Alignment.CenterHorizontally) {
        Spacer(Modifier.height(48.dp))
        WheelGroup {
            WheelPicker(List(24) { it.toString() }, h, { h = it }, width = 64.dp, contentAlignment = Alignment.CenterEnd)
            IText("hours", 17.sp, c.label, FontWeight.SemiBold, modifier = Modifier.width(56.dp).padding(start = 4.dp))
            WheelPicker(List(60) { it.toString() }, m, { m = it }, width = 64.dp, contentAlignment = Alignment.CenterEnd)
            IText("min", 17.sp, c.label, FontWeight.SemiBold, modifier = Modifier.width(48.dp).padding(start = 4.dp))
            WheelPicker(List(60) { it.toString() }, s, { s = it }, width = 64.dp, contentAlignment = Alignment.CenterEnd)
            IText("sec", 17.sp, c.label, FontWeight.SemiBold, modifier = Modifier.width(44.dp).padding(start = 4.dp))
        }
        Spacer(Modifier.height(32.dp))
        Row(Modifier.fillMaxWidth().padding(horizontal = 28.dp), horizontalArrangement = Arrangement.SpaceBetween) {
            RoundButton("Cancel", c.fill, c.label, enabled = false) {}
            RoundButton("Start", c.green.copy(alpha = 0.28f), c.green, enabled = totalMs > 0L) {
                vm.timerStart(totalMs)
            }
        }
        Spacer(Modifier.height(36.dp))
        Row(
            Modifier
                .padding(horizontal = 16.dp)
                .fillMaxWidth()
                .clip(RoundedCornerShape(10.dp))
                .background(c.card)
                .tap(onClick = onPickSound)
                .padding(horizontal = 16.dp)
                .height(52.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IText("When Timer Ends", 17.sp, c.label, modifier = Modifier.weight(1f))
            IText(SoundRepo.titleFor(ctx, vm.timer.soundUri), 17.sp, c.secondary, maxLines = 1, modifier = Modifier.padding(end = 8.dp))
            Chevron()
        }
    }
}

@Composable
private fun TimerRunning(vm: ClockViewModel) {
    val c = LocalIos.current
    val ctx = LocalContext.current
    val t = vm.timer
    val running = t.status == TimerStatus.RUNNING
    val is24 = remember { DateFormat.is24HourFormat(ctx) }

    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(running) {
        while (running) {
            now = System.currentTimeMillis()
            delay(50)
        }
    }
    val remaining = if (running) (t.endAt - now).coerceAtLeast(0L) else t.remainingMs
    val fraction = if (t.totalMs > 0) (remaining.toFloat() / t.totalMs).coerceIn(0f, 1f) else 0f
    val secs = ceil(remaining / 1000.0).toLong()
    val text = if (secs >= 3600) String.format(Locale.US, "%d:%02d:%02d", secs / 3600, (secs % 3600) / 60, secs % 60)
    else String.format(Locale.US, "%d:%02d", secs / 60, secs % 60)

    val endAt = if (running) t.endAt else System.currentTimeMillis() + remaining
    val endTime = Instant.ofEpochMilli(endAt).atZone(ZoneId.systemDefault())
    val (endMain, endSuffix) = timeParts(endTime, is24)

    Column(Modifier.fillMaxSize().statusBarsPadding(), horizontalAlignment = Alignment.CenterHorizontally) {
        Spacer(Modifier.height(56.dp))
        Box(Modifier.size(300.dp), contentAlignment = Alignment.Center) {
            Canvas(Modifier.size(300.dp)) {
                val w = 10.dp.toPx()
                val inset = w / 2
                val arcSize = Size(size.width - w, size.height - w)
                drawArc(c.fill, 0f, 360f, false, Offset(inset, inset), arcSize, style = Stroke(w))
                drawArc(c.accent, -90f, 360f * fraction, false, Offset(inset, inset), arcSize, style = Stroke(w, cap = StrokeCap.Round))
            }
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                IText(text, 70.sp, c.label, FontWeight.Light, tnum = true, maxLines = 1)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    TabGlyph(1, c.secondary, filled = false, cut = c.bg, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(6.dp))
                    IText("$endMain${if (endSuffix.isNotEmpty()) " $endSuffix" else ""}", 17.sp, c.secondary, tnum = true)
                }
            }
        }
        Spacer(Modifier.height(40.dp))
        Row(Modifier.fillMaxWidth().padding(horizontal = 28.dp), horizontalArrangement = Arrangement.SpaceBetween) {
            RoundButton("Cancel", c.fill, c.label) { vm.timerCancel() }
            if (running) RoundButton("Pause", c.accent.copy(alpha = 0.28f), c.accent) { vm.timerPause() }
            else RoundButton("Resume", c.green.copy(alpha = 0.28f), c.green) { vm.timerResume() }
        }
    }
}
