package app.iosclock.ui

import android.os.SystemClock
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameMillis
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.iosclock.ClockViewModel
import java.util.Locale

fun formatStopwatch(ms: Long): String {
    val t = ms / 10
    val cs = t % 100
    val s = (t / 100) % 60
    val m = (t / 6000) % 60
    val h = t / 360000
    return if (h > 0) String.format(Locale.US, "%d:%02d:%02d.%02d", h, m, s, cs)
    else String.format(Locale.US, "%02d:%02d.%02d", m, s, cs)
}

@Composable
fun StopwatchScreen(vm: ClockViewModel) {
    val c = LocalIos.current
    val sw = vm.stopwatch
    var nowE by remember { mutableLongStateOf(SystemClock.elapsedRealtime()) }
    LaunchedEffect(sw.running) {
        while (sw.running) {
            withFrameMillis { nowE = SystemClock.elapsedRealtime() }
        }
    }
    val elapsed = sw.elapsed(if (sw.running) nowE else SystemClock.elapsedRealtime())

    val lapSum = sw.laps.firstOrNull()?.totalMs ?: 0L
    val currentLap = (elapsed - lapSum).coerceAtLeast(0L)
    val completed = sw.laps.map { it.lapMs }
    val best = if (completed.size >= 2) completed.min() else null
    val worst = if (completed.size >= 2) completed.max() else null

    Column(Modifier.fillMaxSize().statusBarsPadding(), horizontalAlignment = Alignment.CenterHorizontally) {
        Spacer(Modifier.height(72.dp))
        BoxWithConstraints(Modifier.fillMaxWidth().padding(horizontal = 16.dp), contentAlignment = Alignment.Center) {
            val size = (maxWidth.value / 4.4f).coerceAtMost(88f).sp
            IText(formatStopwatch(elapsed), size, c.label, FontWeight.Thin, tnum = true, maxLines = 1, align = TextAlign.Center)
        }
        Spacer(Modifier.height(36.dp))
        Row(Modifier.fillMaxWidth().padding(horizontal = 28.dp), horizontalArrangement = Arrangement.SpaceBetween) {
            if (sw.running) {
                RoundButton("Lap", c.fill, c.label) { vm.stopwatchLap() }
                RoundButton("Stop", c.red.copy(alpha = 0.28f), c.red) { vm.stopwatchStop() }
            } else {
                RoundButton("Reset", c.fill, c.label, enabled = elapsed > 0L) { vm.stopwatchReset() }
                RoundButton("Start", c.green.copy(alpha = 0.28f), c.green) { vm.stopwatchStart() }
            }
        }
        Spacer(Modifier.height(24.dp))
        Hairline()
        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(horizontal = 20.dp)) {
            if (sw.laps.isNotEmpty()) {
                item(key = "current") {
                    LapRow("Lap ${sw.laps.size + 1}", currentLap, c.label)
                }
            }
            items(sw.laps, key = { it.number }) { lap ->
                val color = when (lap.lapMs) {
                    best -> c.green
                    worst -> c.red
                    else -> c.label
                }
                LapRow("Lap ${lap.number}", lap.lapMs, color)
            }
        }
    }
}

@Composable
private fun LapRow(name: String, ms: Long, color: Color) {
    Column {
        Row(
            Modifier.fillMaxWidth().height(46.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            IText(name, 17.sp, color)
            IText(formatStopwatch(ms), 17.sp, color, tnum = true)
        }
        Hairline()
    }
}
