package app.iosclock.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color

/** iOS system colors (dark / light). */
@Immutable
data class IosColors(
    val bg: Color,
    val card: Color,
    val label: Color,
    val secondary: Color,
    val separator: Color,
    val accent: Color,
    val green: Color,
    val red: Color,
    val fill: Color,
    val tabBar: Color
)

val DarkColors = IosColors(
    bg = Color(0xFF000000),
    card = Color(0xFF1C1C1E),
    label = Color(0xFFFFFFFF),
    secondary = Color(0xFF8E8E93),
    separator = Color(0xFF38383A),
    accent = Color(0xFFFF9F0A),
    green = Color(0xFF30D158),
    red = Color(0xFFFF453A),
    fill = Color(0xFF333336),
    tabBar = Color(0xFF121213)
)

val LightColors = IosColors(
    bg = Color(0xFFFFFFFF),
    card = Color(0xFFF2F2F7),
    label = Color(0xFF000000),
    secondary = Color(0xFF8E8E93),
    separator = Color(0xFFC6C6C8),
    accent = Color(0xFFFF9500),
    green = Color(0xFF34C759),
    red = Color(0xFFFF3B30),
    fill = Color(0xFFE5E5EA),
    tabBar = Color(0xFFF7F7F7)
)

val LocalIos = staticCompositionLocalOf { DarkColors }

@Composable
fun IosTheme(content: @Composable () -> Unit) {
    val colors = if (isSystemInDarkTheme()) DarkColors else LightColors
    CompositionLocalProvider(LocalIos provides colors) { content() }
}
