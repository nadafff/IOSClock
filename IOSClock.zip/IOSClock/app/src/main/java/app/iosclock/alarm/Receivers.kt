package app.iosclock.alarm

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat
import app.iosclock.data.ClockRepository
import app.iosclock.data.TimerStatus
import app.iosclock.ring.RingService

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val id = intent.getIntExtra(RingService.EXTRA_ALARM_ID, -1)
        val snoozed = intent.getBooleanExtra(AlarmScheduler.EXTRA_SNOOZED, false)
        val repo = ClockRepository.get(context)
        val alarms = repo.loadAlarms()
        val alarm = alarms.firstOrNull { it.id == id }

        if (alarm != null && !snoozed) {
            if (!alarm.enabled) return // stale firing of a disabled alarm
            if (alarm.days.isEmpty()) {
                // One-shot alarms switch themselves off after ringing (same as iOS).
                repo.saveAlarms(alarms.map { if (it.id == id) it.copy(enabled = false) else it })
            } else {
                AlarmScheduler.schedule(context, alarm)
            }
        }
        ring(context, RingService.KIND_ALARM, id)
    }
}

class TimerReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val repo = ClockRepository.get(context)
        val t = repo.loadTimer()
        if (t.status != TimerStatus.RUNNING) return
        repo.saveTimer(t.copy(status = TimerStatus.IDLE, endAt = 0L, remainingMs = 0L))
        ring(context, RingService.KIND_TIMER, -1)
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        AlarmScheduler.rescheduleAll(context)
    }
}

private fun ring(context: Context, kind: Int, id: Int) {
    val i = Intent(context, RingService::class.java)
        .putExtra(RingService.EXTRA_KIND, kind)
        .putExtra(RingService.EXTRA_ALARM_ID, id)
    ContextCompat.startForegroundService(context, i)
}
